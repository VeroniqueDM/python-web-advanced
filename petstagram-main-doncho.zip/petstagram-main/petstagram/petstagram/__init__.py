'''
# NEW app:
0. Move app inside project dir
1. Add the app in settings.py (INSTALLED_APPS)
2. Create urls.py with empty `urlpatterns` inside the app
3. Include app's urls.py into project urls.py
'''
